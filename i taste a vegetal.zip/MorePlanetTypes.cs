﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Security.Permissions;
using System.Text;
using BepInEx;
using HarmonyLib;
using MorePlanetTypes.Protos;
using Unity;
using xiaoye97;


[module: UnverifiableCode]
[assembly: SecurityPermission(SecurityAction.RequestMinimum, SkipVerification = true)]


namespace MorePlanetTypes {
    [BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", "1.8.0")]
    [BepInPlugin("org.bepinex.plugins.moreplanettypes", "More planet types", "1.0.0")]
    [BepInProcess("DSPGAME.exe")]
    public class MorePlanetTypes : BaseUnityPlugin {
        internal void Awake() {
            Harmony harmony = new Harmony("zorb.dsp.plugins.moreplanettypes");
            LDBTool.PostAddDataAction += Veges.Add;
        }
    }
}

