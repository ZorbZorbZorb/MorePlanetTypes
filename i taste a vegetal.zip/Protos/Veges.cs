﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Security.Permissions;
using System.Text;
using xiaoye97;


[module: UnverifiableCode]
[assembly: SecurityPermission(SecurityAction.RequestMinimum, SkipVerification = true)]


namespace MorePlanetTypes.Protos {
    public static class Veges {
        public static void Add() {
            VegeProto vege126 = LDB.veges.Select(126);
            VegeProto newVege = vege126.Copy();
            newVege.ID = 128;
            newVege.name = "TestVege";
            LDBTool.PostAddProto(ProtoType.Vege, newVege);
        }
    }
}

